// http://www.omdbapi.com/?apikey=[yourkey]
// Here is your key: 2b6d80ca
// http://www.omdbapi.com/?apikey=2b6d80ca&t=sherlock&type=movie&plot=full
const getData = async()=>{
    try{
        let movieName =  document.getElementById('searchText').value
        let res = await fetch(`http://www.omdbapi.com/?apikey=2b6d80ca&s=${movieName}`)
        res = await res.json()
        
        console.log(res.Search)
        appendData(res.Search)
    }
    catch(err){
        console.log(err)
    }
}

function appendData(data){
    // console.log(data)
    let container = document.getElementById('movieContainer')
    container.addEventListener('click',getMovieID)
    container.innerHTML = null
    data.forEach((el)=>{
        
        let card = document.createElement('div')
        // card.id = el.imdbID // id will be unique
        card.className = 'card'

        card.innerHTML = ` <img src=${el.Poster} alt="">
        <p>${el.Title}</p>
        <p>${el.Year}</p>`
        // card.addEventListener('click',getMovieID)
        
        container.append(card)
    })

}
function getMovieID(e){
    // Element.closest('selecor')
    const myCard = e.target.closest('.card')

    // Element.parentNode
    // Element.previousSibling
    
    // console.log(myCard)
    if(myCard !== null){

        localStorage.setItem('movieID',myCard.Title)
        
        // window.location.href =  './movieDetails.html'
    }
}
