const getData = async()=>{
    try{
        
        // let movieName =  document.getElementById('searchText').value
        let moiveID = localStorage.getItem('movieID')
        let res = await fetch(`http://www.omdbapi.com/?apikey=2b6d80ca&i=${moiveID}`)
        res = await res.json()
        
        console.log(res)
        // appendData(res.Search)
        appendData(res)
    }
    catch(err){
        console.log(err)
    }
}
getData()

function appendData(obj){
    
    let container = document.createElement('div')
    container.style.border = '1px solid black'
    container.innerHTML = `<p>${obj.Title}</p>
    <p>${obj.Actors}</p>`

    document.body.append(container)
}